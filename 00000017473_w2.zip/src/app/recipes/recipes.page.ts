import { Component, OnInit } from '@angular/core';
import { Recipe } from './recipes.model';
import { RecipesService } from './recipes.service';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.page.html',
  styleUrls: ['./recipes.page.scss'],
})
export class RecipesPage implements OnInit {

  recipes: Recipe[];

  // recipes: Recipe[] = [
  //   {
  //   id: 'r1',
  //   title: 'Gado-gado',
  //   imageUrl:
  //   'https://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe/recipe-image/2016/05/gado-gadosalad.jpg?itok=MTTSriC8',
  //   ingredients: ['Lontong', 'Sawi', 'Bumbu Kecap', 'Tauge'],
  //   },
  //   {
  //     id: 'r2',
  //     title: 'Ketupat',
  //     imageUrl:
  //     'https://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe/recipe-image/2016/05/gado-gadosalad.jpg?itok=MTTSriC8',
  //     ingredients: ['Lontong', 'Sawi', 'Bumbu Kecap', 'Tauge'],
  //     },
  //     {
  //       id: 'r3',
  //       title: 'Pizza',
  //       imageUrl:
  //       'https://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe/recipe-image/2016/05/gado-gadosalad.jpg?itok=MTTSriC8',
  //       ingredients: ['Lontong', 'Sawi', 'Bumbu Kecap', 'Tauge'],
  //       },
  // ];
  constructor(private recipesService: RecipesService) { }

  ngOnInit() {
    this.recipes = this.recipesService.getAllRecipes();
    console.log(this.recipesService.getRecipe("r1"));
  }

}
