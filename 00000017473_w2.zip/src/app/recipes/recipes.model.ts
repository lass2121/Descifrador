export interface Recipe{
    id : String;
    title : String;
    imageUrl : String;
    ingredients: String[];
  }