import { Injectable } from '@angular/core';
import { Recipe } from './recipes.model';

@Injectable({
  providedIn: 'root'
})
export class RecipesService {

  private recipes: Recipe[] = [
    {
    id: 'r1',
    title: 'Gado-gado',
    imageUrl:
    'https://www.bbcgoodfood.com/sites/default/files/recipe/recipe-image/2016/05/gado-gado-salad.jpg',
    ingredients: ['Lontong', 'Sawi', 'Bumbu Kecap',
    'Tauge']
    },
    {
      id: 'r2',
      title: 'Ketupat',
      imageUrl:
      'https://asset.kompas.com/crop/1x0:800x533/750x500/data/photo/2018/06/14/2225305048.jpg',
      ingredients: ['Lontong', 'Sawi', 'Bumbu Kecap', 'Tauge'],
      },
      {
        id: 'r3',
        title: 'Pizza',
        imageUrl:
        'https://i.ytimg.com/vi/o4BLb0V9Weg/maxresdefault.jpg',
        ingredients: ['Lontong', 'Sawi', 'Bumbu Kecap', 'Tauge'],
        },
  
    ];

  constructor() { }

  getAllRecipes() {
    return [...this.recipes];
  }

    getRecipe(recipeId: string) {
      return {
        ...this.recipes.find(recipe => {
        return recipe.id === recipeId;
        })
        };
    }

    deleteRecipe(recipeId: string){
      this.recipes = this.recipes.filter(recipe => {
        return recipe.id !== recipeId;
      });


     }
}
